"""F9.4 Thanh toán bằng Education Account (TC-063 đến TC-086). Nguồn: R9_Test_Cases_final_FS09.xlsx, FS F9 mục SCR-05, SCR-06.

Test nhãn mutating tiêu khoản phí và trừ tiền ví thật, chỉ chạy khi R9_ALLOW_PAYMENTS=1 (run_r9_automation.cmd pay).
Mỗi test đọc lại số dư và danh sách khoản trên trang ngay trước khi trả, không tin Catalog đã đọc từ đầu phiên,
vì test trước có thể đã tiêu khoản đó. Hết khoản hoặc hết tiền thì test tự bỏ qua kèm lý do.
Bản rev FS09 thêm hậu điều kiện: transaction và leg EA Succeeded, invoice Paid, số dư EA giảm đúng số tiền. Các test mutating
đọc lại transaction và invoice qua API (pages/postconditions.py) thay vì chỉ tin màn kết quả.
"""
from __future__ import annotations

import json
import re
from decimal import Decimal

import pytest
from playwright.sync_api import expect

from data import mocks, seed
from data import ui_text as T
from pages.base_page import GUID_RE, snippet, wait_until
from pages.billing_page import BillingPage
from pages.catalog import live_smallest, need
from pages.postconditions import assert_backend_state
from pages.result_page import ResultPage

pytestmark = pytest.mark.f94

RESULT_URL = re.compile(r"/payment-result")


def pay_and_wait(page, billing, result, descriptions, method=T.METHOD_EA):
    billing.start(descriptions, method)
    billing.authorize()
    page.wait_for_url(RESULT_URL, timeout=45_000)
    result.wait_final()


@pytest.mark.extra
def test_extra_review_for_education_account_shows_method_and_amount_split(billing, catalog):
    """Bổ sung (gần TC-063, TC-087) Bước xem lại hiện phương thức Education Account, phần EA bằng tổng, phần online bằng 0. Không bấm thanh toán."""
    child = need(catalog.ea_child(), "con có ví đủ trả khoản phí nhỏ nhất")
    (charge,), _ = live_smallest(billing, child, need_balance=True)
    billing.start([charge.description], T.METHOD_EA)
    facts = dict(billing.review_facts())
    assert facts["Payment method"] == "Education Account", facts
    assert facts["Education Account"].endswith(f"{charge.net:.2f}"), facts
    assert facts["Online Gateway"].endswith("0.00"), facts
    expect(billing.authorize_button).to_contain_text(f"{charge.net:.2f}")


@pytest.mark.mutating
def test_tc_065_tc_070_tc_129_pay_one_charge_with_education_account_end_to_end(page, billing, result, catalog, api):
    """TC-065, TC-070, TC-129 Trả một khoản bằng EA: kết quả thành công, số tiền khớp, hóa đơn Paid, khoản biến mất, ví giảm đúng số tiền.
    Hậu điều kiện rev FS09: transaction Succeeded, leg EA Succeeded, invoice Paid (đọc qua API), không có leg online."""
    child = need(catalog.ea_child(), "con có ví đủ trả khoản phí nhỏ nhất")
    (charge,), balance_before = live_smallest(billing, child, need_balance=True)
    outstanding_before = billing.outstanding_total()

    pay_and_wait(page, billing, result, [charge.description])

    assert result.title() == T.RESULT_SUCCEEDED, f"Kết quả: {result.title()}; {result.text()[:300]}"
    assert GUID_RE.match(result.fact("Transaction ID") or ""), result.facts()
    assert result.amount("Requested amount") == charge.net
    assert result.amount("Settled amount") == charge.net
    rows = result.funding_rows()
    assert len(rows) == 1 and rows[0][0] == "Education Account — Succeeded", rows
    assert result.fact("Invoice status") == "Paid", result.facts()
    assert result.invoice_item_count() == 1
    expect(result.print_button).to_be_visible()
    assert_backend_state(api, result.transaction_id(), status="Succeeded", legs={T.METHOD_EA: "Succeeded"}, invoice="Paid")

    billing.open(child.student_id)
    assert charge.description not in [c.description for c in billing.read_charges()], "Khoản đã trả vẫn còn trong danh sách"
    assert billing.balance() == balance_before - charge.net, "Ví không giảm đúng số tiền đã trả"
    assert billing.outstanding_total() == outstanding_before - charge.net


@pytest.mark.mutating
def test_tc_067_two_charges_in_one_payment_create_one_invoice_with_two_lines(page, billing, result, catalog, api):
    """TC-067 Trả hai khoản cùng lúc bằng EA: một giao dịch, hóa đơn có hai dòng, tổng đúng.
    Hậu điều kiện rev FS09: transaction và leg EA Succeeded, invoice Paid, màn kết quả có mã giao dịch.
    Số dòng 1 và 2 không trùng nhau trong cùng hóa đơn cũng là phần quan sát được của TC-169."""
    child = need(next((c for c in catalog.with_charges() if len(c.charges) >= 2 and c.balance >= sum(
        (x.net for x in c.smallest(2)), Decimal(0))), None), "con có từ hai khoản phí và ví đủ trả hai khoản nhỏ nhất")
    picked, balance_before = live_smallest(billing, child, count=2, need_balance=True)
    total = sum((c.net for c in picked), Decimal(0))

    pay_and_wait(page, billing, result, [c.description for c in picked])

    assert result.title() == T.RESULT_SUCCEEDED, result.text()[:300]
    assert result.amount("Requested amount") == total
    assert result.invoice_item_count() == 2
    assert sorted(result.invoice_line_numbers()) == ["1", "2"], result.invoice_line_numbers()
    assert [r[0] for r in result.funding_rows()] == ["Education Account — Succeeded"], result.funding_rows()
    assert result.fact("Invoice status") == "Paid", result.facts()
    assert_backend_state(api, result.transaction_id(), status="Succeeded", legs={T.METHOD_EA: "Succeeded"}, invoice="Paid")
    billing.open(child.student_id)
    assert billing.balance() == balance_before - total


@pytest.mark.mutating
def test_tc_077_double_click_on_authorize_sends_one_checkout_request(page, billing, result, catalog, requests_log, api):
    """TC-077 Bấm Authorize & pay hai lần liên tiếp chỉ gửi một yêu cầu thanh toán, ví chỉ bị trừ một lần.
    Hậu điều kiện rev FS09: invoice Paid, transaction và leg EA Succeeded."""
    child = need(catalog.ea_child(), "con có ví đủ trả khoản phí nhỏ nhất")
    (charge,), balance_before = live_smallest(billing, child, need_balance=True)
    billing.start([charge.description], T.METHOD_EA)
    billing.authorize_button.dblclick()
    page.wait_for_url(RESULT_URL, timeout=45_000)
    result.wait_final()
    assert len(requests_log.posts("/checkout")) == 1, f"Có {len(requests_log.posts('/checkout'))} yêu cầu thanh toán"
    assert result.title() == T.RESULT_SUCCEEDED, result.text()[:300]
    assert result.fact("Invoice status") == "Paid", result.facts()
    assert_backend_state(api, result.transaction_id(), status="Succeeded", legs={T.METHOD_EA: "Succeeded"}, invoice="Paid")
    billing.open(child.student_id)
    assert billing.balance() == balance_before - charge.net, "Ví bị trừ sai số lần"


@pytest.mark.mutating
def test_tc_084_charge_already_paid_in_another_tab_is_refused_without_double_charge(page, context, billing, result, catalog):
    """TC-084 Hai tab cùng chọn một khoản: tab trả trước thành công, tab sau bị từ chối với thông báo khoản không còn khả dụng."""
    child = need(catalog.ea_child(), "con có ví đủ trả khoản phí nhỏ nhất")
    (charge,), _ = live_smallest(billing, child, need_balance=True)
    billing.start([charge.description], T.METHOD_EA)  # tab A dừng ở bước xem lại

    other = context.new_page()
    b_billing, b_result = BillingPage(other, billing.base_url), ResultPage(other, billing.base_url)
    b_billing.open(child.student_id)
    pay_and_wait(other, b_billing, b_result, [charge.description])
    assert b_result.title() == T.RESULT_SUCCEEDED
    b_billing.open(child.student_id)
    balance_after_first = b_billing.balance()
    other.close()

    billing.authorize()
    expect(billing.stale_alert).to_be_visible(timeout=20_000)
    assert RESULT_URL.search(page.url) is None, "Tab sau vẫn chuyển sang trang kết quả"
    # Rev FS09: không có transaction thứ hai (tab sau không lưu mã giao dịch), invoice vẫn Paid, số dư không đổi.
    assert page.evaluate(f"sessionStorage.getItem({json.dumps(seed.TRANSACTION_STORAGE_KEY)})") is None, "Tab sau đã tạo giao dịch thứ hai"
    billing.open(child.student_id)
    assert charge.description not in [c.description for c in billing.read_charges()], "Khoản đã trả lại hiện trong danh sách"
    assert billing.balance() == balance_after_first, "Khoản bị trừ lần hai"


@pytest.mark.mocked
@pytest.mark.parametrize("status", [404, 409], ids=["404", "409"])
def test_tc_084_tc_086_stale_checkout_clears_selection_and_reloads_the_list(page, billing, catalog, requests_log, status):
    """TC-084 và TC-086 (giả lập) Máy chủ trả 404 hoặc 409 khi thanh toán: báo khoản không còn khả dụng, bỏ chọn, tải lại danh sách."""
    child = need(catalog.ea_child(), "con có ví đủ trả khoản phí nhỏ nhất")
    (charge,), _ = live_smallest(billing, child, need_balance=True)
    billing.start([charge.description], T.METHOD_EA)
    mocks.mock_json(page, mocks.CHECKOUT_RE, None, status=status, message="Charge already used", method="POST")
    fetches_before = requests_log.count("outstanding-charges")
    billing.authorize()
    expect(billing.stale_alert).to_be_visible()
    expect(billing.charges_heading).to_be_visible()
    assert billing.charge_boxes.count() > 0
    for box in billing.charge_boxes.all():
        expect(box).not_to_be_checked()
    expect(billing.continue_button).to_be_disabled()
    wait_until(page, lambda: requests_log.count("outstanding-charges") > fetches_before, what="tải lại danh sách khoản phí")
    assert not billing.checkout_error_alert.count(), "Lỗi dữ liệu chung hiện cùng lúc với thông báo khoản hết hạn"


@pytest.mark.mocked
@pytest.mark.extra
def test_extra_retry_after_server_error_reuses_the_same_idempotency_key(page, billing, catalog):
    """Bổ sung: thử lại sau lỗi 500 phải dùng cùng Idempotency-Key để máy chủ không tạo giao dịch thứ hai (mã nguồn BillingPaymentPage)."""
    child = need(catalog.ea_child(), "con có ví đủ trả khoản phí nhỏ nhất")
    (charge,), _ = live_smallest(billing, child, need_balance=True)
    billing.start([charge.description], T.METHOD_EA)
    keys: list[str] = []

    def handler(route):
        if route.request.method != "POST":
            route.continue_()
            return
        keys.append(route.request.headers.get("idempotency-key", ""))
        mocks.respond(route, None, 500, "boom")

    page.route(mocks.CHECKOUT_RE, handler)
    billing.authorize()
    expect(billing.checkout_error_alert).to_be_visible()
    billing.authorize()
    wait_until(page, lambda: len(keys) > 1, what="lần gửi thứ hai")
    assert keys[0] and keys[0] == keys[1], f"Hai lần gửi dùng khóa khác nhau: {keys}"


@pytest.mark.api
@pytest.mark.mutating
def test_tc_078_tc_080_same_idempotency_key_returns_first_result_and_pays_once(api, catalog, base_url):
    """TC-078 và TC-080 Gửi hai lần cùng một khóa 100 ký tự: lần hai trả lại kết quả lần đầu, ví chỉ bị trừ một lần.
    Tạo một giao dịch thật bằng Education Account cho khoản nhỏ nhất, nên thuộc nhóm mutating."""
    child = need(catalog.ea_child(), "con có ví đủ trả khoản phí nhỏ nhất")
    wallet = api.get(f"/iam/v1/edu-account/students/{child.student_id}/wallet")
    assert wallet.ok, f"Không đọc được ví ({wallet.status}): {snippet(wallet)}"
    wallet_data = wallet.json()["data"]["wallet"]
    charges = api.get(f"/billing/v1/students/{child.student_id}/outstanding-charges").json()["data"]
    if not charges:
        pytest.skip(f"{child.name} không còn khoản phí")
    charge = min(charges, key=lambda c: c["netAmount"])
    if Decimal(str(wallet_data["balance"])) < Decimal(str(charge["netAmount"])):
        pytest.skip("Ví không đủ trả khoản nhỏ nhất")
    key = "r9-qa-same-key-" + "k" * 85
    assert len(key) == 100
    body = {"studentId": child.student_id, "chargeIds": [charge["chargeId"]], "method": T.METHOD_EA, "walletId": wallet_data["walletId"]}
    first = api.post("/billing/v1/checkout", body, key=key)
    assert first.ok, f"Lần đầu bị từ chối ({first.status}): {snippet(first)}"
    second = api.post("/billing/v1/checkout", body, key=key)
    assert second.ok, f"Lần hai cùng khóa bị từ chối ({second.status}): {snippet(second)}"
    assert second.json()["data"]["transactionId"] == first.json()["data"]["transactionId"], "Lần hai tạo giao dịch khác"
    # Hậu điều kiện rev FS09 (TC-078 bước 5, TC-080 bước 2): transaction và leg EA Succeeded, invoice Paid, ví chỉ giảm một lần.
    assert_backend_state(api, first.json()["data"]["transactionId"], status="Succeeded", legs={T.METHOD_EA: "Succeeded"}, invoice="Paid")
    after = api.get(f"/iam/v1/edu-account/students/{child.student_id}/wallet").json()["data"]["wallet"]["balance"]
    assert Decimal(str(after)) == Decimal(str(wallet_data["balance"])) - Decimal(str(charge["netAmount"])), "Ví bị trừ sai số lần"
    remaining = api.get(f"/billing/v1/students/{child.student_id}/outstanding-charges").json()["data"]
    assert charge["chargeId"] not in [c["chargeId"] for c in remaining], "Khoản đã trả vẫn còn trong danh sách còn nợ"
