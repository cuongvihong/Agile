"""F9.5 Thanh toán online và chia khoản Both (TC-087 đến TC-103, TC-130, TC-136, TC-137, TC-139). Nguồn: R9_Test_Cases_final_FS09.xlsx.

Cần trang giả lập cổng thanh toán (npm run dev:payment-checkout, cổng 5176) và mở e-service bằng localhost, vì
AllowedReturnOrigins của simulator chỉ cho localhost 5176 và 5174. Test online không có simulator sẽ tự bỏ qua.
Test nhãn destructive rút cạn ví của một con. Chạy từng test một rồi reset dữ liệu (tools/reset_payment_data.sql).
Các test mocked cuối file không cần simulator.
Bản rev FS09 thêm hậu điều kiện cho transaction, từng leg và invoice. Các test mutating đọc chúng qua API (pages/postconditions.py).
"""
from __future__ import annotations

import json
from decimal import Decimal

import pytest
from playwright.sync_api import expect

from data import mocks, seed
from data import ui_text as T
from pages.catalog import live_smallest, need
from pages.postconditions import assert_backend_state

pytestmark = pytest.mark.f95


def live_first_charge(billing, child):
    billing.open(child.student_id)
    charges = sorted(billing.read_charges(), key=lambda c: (c.net, c.description))
    if not charges:
        pytest.skip(f"{child.name} không còn khoản phí (test trước đã tiêu)")
    return charges[0], billing.balance()


def go_online(page, billing, simulator, result, outcome: str) -> None:
    """Từ bước xem lại: bấm Authorize & pay, qua trang giả lập, bấm kết quả, chờ kết quả cuối ở e-service."""
    billing.authorize()
    simulator.wait_loaded()
    (simulator.pay_successful if outcome == "ok" else simulator.pay_failed)()
    simulator.wait_return_to_merchant()
    result.wait_final()


# ------------------------------------------------------------------ chỉ Online Gateway
@pytest.mark.online
@pytest.mark.mutating
def test_tc_087_tc_088_tc_089_pay_one_charge_online_leaves_education_account_untouched(page, billing, simulator, result, catalog, requests_log, api):
    """TC-087, TC-088, TC-089 Trả một khoản qua Online Gateway (TC-088 gốc dùng học sinh không có EA, ở đây dùng con có EA): sang trang cổng, trả thành công, ví EA không đổi, khoản biến mất.
    Hậu điều kiện rev FS09: màn xem lại chưa tạo gì (TC-087); sau khi trả, transaction và leg online Succeeded, không có leg EA (TC-089)."""
    child = need(catalog.with_charges()[0] if catalog.with_charges() else None, "con có khoản phí chưa trả")
    charge, balance_before = live_first_charge(billing, child)
    billing.start([charge.description], T.METHOD_ONLINE)
    facts = dict(billing.review_facts())
    assert facts["Payment method"] == "Online Gateway" and facts["Education Account"].endswith("0.00"), facts
    assert not requests_log.posts("/checkout"), "Màn xem lại đã tạo giao dịch trước khi bấm xác nhận"

    go_online(page, billing, simulator, result, "ok")

    assert result.title() == T.RESULT_SUCCEEDED, f"{result.title()}; {result.text()[:300]}"
    assert result.amount("Requested amount") == charge.net and result.amount("Settled amount") == charge.net
    rows = result.funding_rows()
    assert [r[0] for r in rows] == ["Online Gateway — Succeeded"], rows
    assert result.fact("Invoice status") == "Paid", result.facts()
    assert_backend_state(api, result.transaction_id(), status="Succeeded", legs={T.METHOD_ONLINE: "Succeeded"}, invoice="Paid")
    billing.open(child.student_id)
    assert billing.balance() == balance_before, "Trả online mà ví EA vẫn bị trừ"
    assert charge.description not in [c.description for c in billing.read_charges()]


@pytest.mark.online
@pytest.mark.mutating
def test_tc_136_online_payment_failure_shows_failed_result_and_keeps_balance(page, billing, simulator, result, catalog, api):
    """TC-136 Cổng báo thất bại: màn kết quả báo thất bại, hóa đơn không Paid, số dư EA không đổi.
    Hậu điều kiện rev FS09: transaction và leg online Failed (đọc qua API). Việc invoice trở lại Issued xem test TC-090 và TC-139."""
    child = need(catalog.with_charges()[0] if catalog.with_charges() else None, "con có khoản phí chưa trả")
    charge, balance_before = live_first_charge(billing, child)
    billing.start([charge.description], T.METHOD_ONLINE)

    go_online(page, billing, simulator, result, "fail")

    assert result.title() == T.RESULT_FAILED, f"{result.title()}; {result.text()[:300]}"
    expect(result.page.get_by_text("Your payment could not be completed", exact=False)).to_be_visible()
    assert result.fact("Invoice status") != "Paid"
    assert [r[0] for r in result.funding_rows()] == ["Online Gateway — Failed"], result.funding_rows()
    assert_backend_state(api, result.transaction_id(), status="Failed", legs={T.METHOD_ONLINE: "Failed"})
    billing.open(child.student_id)
    assert billing.balance() == balance_before


@pytest.mark.online
@pytest.mark.mutating
@pytest.mark.known_defect(reason="Sau khi cổng thất bại, khoản phí không quay lại danh sách nên không thử lại được (F9_Dev_Local_Run_Results.md, R9 TC-090, TC-139)")
def test_tc_090_tc_139_charge_is_available_again_after_online_failure(page, billing, simulator, result, catalog, api):
    """TC-090 và TC-139 Sau khi thanh toán online thất bại, khoản phí vẫn nằm trong danh sách để thử lại.
    Hậu điều kiện rev FS09 (TC-136): invoice trở lại Issued sau khi transaction Failed."""
    child = need(catalog.with_charges()[0] if catalog.with_charges() else None, "con có khoản phí chưa trả")
    charge, _ = live_first_charge(billing, child)
    billing.start([charge.description], T.METHOD_ONLINE)
    go_online(page, billing, simulator, result, "fail")
    assert result.title() == T.RESULT_FAILED
    assert_backend_state(api, result.transaction_id(), status="Failed", legs={T.METHOD_ONLINE: "Failed"}, invoice="Issued")
    billing.open(child.student_id)
    assert charge.description in [c.description for c in billing.read_charges()], "Khoản phí đã biến mất sau khi thanh toán thất bại"


# ------------------------------------------------------------------ Both: chia khoản
def split_setup(billing, catalog):
    child = need(catalog.split_child(), "con có ví còn tiền nhưng không đủ trả hết khoản phí")
    billing.open(child.student_id)
    balance = billing.balance()
    total = billing.outstanding_total()
    if not 0 < balance < total:
        pytest.skip(f"{child.name} không còn ở trạng thái chia khoản (ví {balance}, nợ {total}). Reset dữ liệu rồi chạy lại")
    billing.select_all().to_method()
    assert billing.method_state()[T.METHOD_BOTH]["checked"], "Both không phải mặc định"
    billing.to_review()
    return child, balance, total


@pytest.mark.online
@pytest.mark.mutating
@pytest.mark.destructive
def test_tc_097_tc_130_split_payment_succeeds_with_both_funding_sources(page, billing, simulator, result, catalog, api):
    """TC-097 và TC-130 Both: EA trả hết số dư, online trả phần còn lại, kết quả thành công với hai dòng nguồn tiền.
    Hậu điều kiện rev FS09 (TC-130): transaction, leg EA và leg online Succeeded, invoice Paid, số dư EA về 0.00."""
    child, balance, total = split_setup(billing, catalog)
    online_part = total - balance

    go_online(page, billing, simulator, result, "ok")

    assert result.title() == T.RESULT_SUCCEEDED, f"{result.title()}; {result.text()[:300]}"
    assert result.amount("Requested amount") == total and result.amount("Settled amount") == total
    rows = dict(result.funding_rows())
    assert set(rows) == {"Education Account — Succeeded", "Online Gateway — Succeeded"}, rows
    assert f"{balance:,.2f}" in rows["Education Account — Succeeded"] and f"{online_part:,.2f}" in rows["Online Gateway — Succeeded"], rows
    assert result.fact("Invoice status") == "Paid", result.facts()
    assert_backend_state(api, result.transaction_id(), status="Succeeded",
                         legs={T.METHOD_EA: "Succeeded", T.METHOD_ONLINE: "Succeeded"}, invoice="Paid")
    billing.open(child.student_id)
    assert billing.balance() == Decimal("0.00"), "Ví EA chưa về 0 sau khi trả phần EA"
    expect(billing.empty_state).to_be_visible()


@pytest.mark.online
@pytest.mark.mutating
@pytest.mark.destructive
@pytest.mark.known_defect(reason="Khi phần online thất bại, phần Education Account đã trừ không được hoàn lại (F9_Dev_Local_Run_Results.md, R9 TC-103, TC-137)")
def test_tc_103_tc_137_failed_online_part_returns_the_education_account_part(page, billing, simulator, result, catalog, api):
    """TC-103 và TC-137 Both mà phần online thất bại thì phần EA phải được hoàn, ví về đúng số dư trước đó.
    Hậu điều kiện rev FS09: transaction Failed, leg EA Reversed, leg online Failed, invoice Issued, số dư EA trở lại như trước."""
    child, balance, _ = split_setup(billing, catalog)

    go_online(page, billing, simulator, result, "fail")

    assert_backend_state(api, result.transaction_id(), status="Failed",
                         legs={T.METHOD_EA: "Reversed", T.METHOD_ONLINE: "Failed"}, invoice="Issued")
    assert result.title() in (T.RESULT_FAILED, T.RESULT_REVIEW), result.title()
    rows = dict(result.funding_rows())
    assert "Education Account — Refunded" in rows, f"Không thấy dòng hoàn tiền EA: {rows}"
    billing.open(child.student_id)
    assert billing.balance() == balance, "Phần EA đã trừ chưa được hoàn lại"


# ------------------------------------------------------------------ giả lập phản hồi checkout
@pytest.mark.mocked
@pytest.mark.extra
def test_extra_invalid_checkout_url_from_provider_starts_no_payment(page, billing, catalog):
    """Bổ sung: cổng trả checkoutUrl không hợp lệ thì hiện 'Unable to open online payment' và không chuyển trang."""
    child = need(catalog.with_charges()[0] if catalog.with_charges() else None, "con có khoản phí chưa trả")
    (charge,), _ = live_smallest(billing, child)
    billing.start([charge.description], T.METHOD_ONLINE)
    mocks.mock_json(page, mocks.CHECKOUT_RE, mocks.checkout_result(checkout_url="not a url"), method="POST")
    billing.authorize()
    expect(billing.alert(T.INVALID_URL_TITLE)).to_be_visible()
    assert "/billing/" in page.url, f"Đã rời trang thanh toán: {page.url}"
    assert page.evaluate(f"sessionStorage.getItem({json.dumps(seed.TRANSACTION_STORAGE_KEY)})") is None


@pytest.mark.mocked
@pytest.mark.extra
def test_extra_invalid_transaction_id_from_checkout_is_not_stored(page, billing, catalog):
    """Bổ sung: checkout trả mã giao dịch sai định dạng thì báo 'The transaction reference is invalid.' và không lưu mã."""
    child = need(catalog.with_charges()[0] if catalog.with_charges() else None, "con có khoản phí chưa trả")
    (charge,), _ = live_smallest(billing, child)
    billing.start([charge.description], T.METHOD_ONLINE)
    mocks.mock_json(page, mocks.CHECKOUT_RE, mocks.checkout_result(transaction_id="not-a-guid",
                    checkout_url="http://localhost:5176/checkout/x"), method="POST")
    billing.authorize()
    expect(billing.checkout_error_alert).to_contain_text(T.RESULT_INVALID)
    assert "/billing/" in page.url
    assert page.evaluate(f"sessionStorage.getItem({json.dumps(seed.TRANSACTION_STORAGE_KEY)})") is None
