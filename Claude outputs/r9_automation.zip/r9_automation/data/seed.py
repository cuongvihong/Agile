"""Cấu hình môi trường và dữ liệu mẫu của FS09. Mọi giá trị đổi được bằng biến môi trường.

Hai địa chỉ của hệ thống đang kiểm thử:
  e-service     R9_BASE_URL   mặc định http://localhost:5174  (cổng phụ huynh, nơi chạy mọi test thanh toán)
  admin portal  R9_ADMIN_URL  mặc định http://localhost:5173  (cổng quản trị, hiện chỉ kiểm tra mở được và đòi đăng nhập)

Dữ liệu mẫu khác nhau giữa các lần nạp. Lần quét trên bản chạy local ngày 21/10/2026 (persona MockPass S7890123F):
Test Child One (10 khoản, tổng 805.00, ví 300.00), Test Child Two (5 khoản, 1390.00, ví 300.00),
Test Child Three (5 khoản, 470.00, ví 300.00) và Tan Wei Ming (không có khoản phí, ví 0.00).
Bản nạp cũ theo Function9FullFlowSetup.sql có Noah Lee và Ryan Hassan, ví 1000.00. Suite không gắn cứng tên con:
nó đọc danh sách con trên UI rồi tự chọn con phù hợp (xem pages/catalog.py).
"""
from __future__ import annotations

import os

BASE_URL = os.environ.get("R9_BASE_URL", "http://localhost:5174")
# Cổng quản trị (apps/admin-portal). Chưa có test R9 nào thao tác trong đó: đăng nhập cần tài khoản thật của QA, không có trong repo.
ADMIN_URL = os.environ.get("R9_ADMIN_URL", "http://localhost:5173").rstrip("/")
# Persona MockPass, không phải mật khẩu. Đổi bằng R9_NRIC nếu máy anh map con sang persona khác.
NRIC = os.environ.get("R9_NRIC", "S7890123F")
# Trang thanh toán giả lập (npm run dev:payment-checkout). Chỉ cần cho test có nhãn online.
CHECKOUT_URL = os.environ.get("R9_CHECKOUT_URL", "http://localhost:5176")
# Danh sách con mong đợi, ngăn cách bằng dấu phẩy. Để trống thì bỏ qua TC-006.
EXPECTED_CHILDREN = [x.strip() for x in os.environ.get("R9_EXPECTED_CHILDREN", "").split(",") if x.strip()]
# Cho phép test ghi dữ liệu thật. Runner đặt biến này sau khi anh gõ xác nhận.
ALLOW_PAYMENTS = os.environ.get("R9_ALLOW_PAYMENTS") == "1"
# Cho phép test rút cạn ví của một con (thanh toán chia khoản Both). Cần thêm bước reset dữ liệu giữa các lần chạy.
ALLOW_DESTRUCTIVE = os.environ.get("R9_ALLOW_DESTRUCTIVE") == "1"

TRANSACTION_STORAGE_KEY = "edusave.billingPayment.transactionId"
API_PREFIX = "/api"

# GUID hợp lệ về định dạng nhưng không thuộc về ai, dùng cho test truy cập trái phép.
UNKNOWN_ID = "00000000-0000-4000-8000-000000000001"
UNKNOWN_ID_2 = "00000000-0000-4000-8000-000000000002"
