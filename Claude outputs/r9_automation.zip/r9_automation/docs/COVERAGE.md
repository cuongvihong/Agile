# Độ phủ của R9_Test_Cases_final_FS09.xlsx

Số case trong sổ: 153. Đã tự động hóa: 73. Chưa tự động hóa: 80.

Một case tính là đã tự động hóa khi có ít nhất một test chạy được cho nó, kể cả test nhãn `known_defect` (kỳ vọng thất bại vì bản build lệch với R9),
`mocked` (giả phản hồi), `mutating` (ghi dữ liệu thật) và `draft` (phụ thuộc giả định). Xem README để biết ý nghĩa từng nhãn.

| Suite | Số case | Đã tự động hóa | Chưa |
|---|---|---|---|
| F9.1 Access and child list | 17 | 13 | 4 |
| F9.2 Outstanding invoices and EA balance | 17 | 11 | 6 |
| F9.3 Payment method and eligibility | 23 | 14 | 9 |
| F9.4 Pay with Education Account | 13 | 4 | 9 |
| F9.4 and F9.5 Idempotency and concurrency | 10 | 6 | 4 |
| F9.5 Pay online | 9 | 4 | 5 |
| F9.4 and F9.5 Split payment | 14 | 4 | 10 |
| F9.6 Webhook and reconciliation | 10 | 0 | 10 |
| F9.7 Result, receipt and retry | 19 | 17 | 2 |
| Data rules and constraints | 21 | 0 | 21 |

## Case đã tự động hóa

| Case | Tiêu đề | Test |
|---|---|---|
| TC-001 | Parent signs in with Singpass and reaches the child list | test_f91_access_and_child_list.py::test_tc_001_sign_in_with_singpass_reaches_child_list |
| TC-004 | Child list shows name, school, level, class and outstanding label | test_f91_access_and_child_list.py::test_tc_004_tc_005_child_card_shows_school_level_class_and_outstanding_label |
| TC-005 | Label shows no outstanding invoices for a child without any | test_f91_access_and_child_list.py::test_tc_004_tc_005_child_card_shows_school_level_class_and_outstanding_label |
| TC-006 | Child list contains only the children linked to the Parent | test_f91_access_and_child_list.py::test_tc_006_child_list_contains_only_linked_children |
| TC-007 | Parent without any linked child sees the empty state | test_f91_access_and_child_list.py::test_tc_007_parent_without_linked_child_sees_empty_state |
| TC-008 | Parent with one child reaches that child | test_f91_access_and_child_list.py::test_tc_008_parent_with_one_child_sees_only_that_child |
| TC-010 | System error while loading the child list shows a safe message | test_f91_access_and_child_list.py::test_tc_010_system_error_on_child_list_shows_safe_message_and_retry |
| TC-011 | Changing the student ID in the address is refused | test_f91_access_and_child_list.py::test_tc_011_invalid_student_id_in_address_is_refused |
| TC-012 | API call for the invoices of an unlinked student is refused | test_f91_access_and_child_list.py::test_tc_012_api_for_charges_of_unlinked_student_is_refused |
| TC-013 | API call to read an invoice of another family is refused | test_f91_access_and_child_list.py::test_tc_013_api_for_invoice_of_another_family_is_refused |
| TC-014 | API call to pay an invoice of another family is refused and nothing is debited | test_f91_access_and_child_list.py::test_tc_014_api_to_pay_for_unlinked_student_is_refused |
| TC-015 | API call for the status or receipt of another family's payment is refused | test_f91_access_and_child_list.py::test_tc_015_api_for_transaction_of_another_family_is_refused |
| TC-017 | Request without a session is sent to the sign in | test_f91_access_and_child_list.py::test_tc_017_request_without_session_is_sent_to_sign_in<br>test_f91_access_and_child_list.py::test_tc_017_protected_api_rejects_call_without_session |
| TC-018 | Open invoices of the chosen child are listed with number, due date, status and amount | test_f92_outstanding_and_balance.py::test_tc_018_open_charges_are_listed_with_description_due_date_and_amounts |
| TC-020 | Invoice totals show Gross, Subsidy 0.00 and Net equal to Gross | test_f92_outstanding_and_balance.py::test_tc_020_gross_subsidy_zero_and_net_equal_gross |
| TC-021 | Amounts are shown in SGD with two decimals | test_f92_outstanding_and_balance.py::test_tc_021_amounts_are_in_sgd_with_two_decimals |
| TC-023 | Switching to another child changes the invoice list | test_f92_outstanding_and_balance.py::test_tc_023_switching_to_another_child_changes_the_charge_list |
| TC-028 | A child with an Active EA shows balance and status | test_f92_outstanding_and_balance.py::test_tc_028_active_account_shows_balance_and_status |
| TC-029 | A child without an EA shows no balance and a note | test_f92_outstanding_and_balance.py::test_tc_029_child_without_education_account_shows_a_note_instead_of_balance |
| TC-030 | A child with a Closed EA shows the status Closed | test_f92_outstanding_and_balance.py::test_tc_030_closed_education_account_shows_status_closed |
| TC-031 | A zero EA balance is shown as 0.00 | test_f92_outstanding_and_balance.py::test_tc_031_zero_balance_is_shown_as_0_00 |
| TC-032 | A child with no Issued invoice shows the empty state | test_f92_outstanding_and_balance.py::test_tc_032_child_without_charges_shows_empty_state_and_no_payment_option<br>test_f92_outstanding_and_balance.py::test_tc_032_real_child_without_charges_shows_empty_state_and_no_payment_option<br>test_f92_outstanding_and_balance.py::test_tc_032_tc_033_real_empty_state_links_back_to_child_list<br>test_f92_outstanding_and_balance.py::test_tc_032_tc_033_empty_state_links_back_to_child_list |
| TC-033 | The empty state links back to the child list and another child can be chosen | test_f92_outstanding_and_balance.py::test_tc_032_tc_033_real_empty_state_links_back_to_child_list<br>test_f92_outstanding_and_balance.py::test_tc_032_tc_033_empty_state_links_back_to_child_list |
| TC-035 | Selecting an Issued invoice opens the payment method screen with its summary | test_f93_method_and_eligibility.py::test_tc_035_selecting_a_charge_opens_method_screen_with_its_summary |
| TC-036 | Only one whole invoice can be selected and lines cannot be paid separately | test_f93_method_and_eligibility.py::test_tc_036_several_charges_can_be_selected_for_one_payment |
| TC-038 | Student without an EA can pay online only | test_f93_method_and_eligibility.py::test_tc_038_student_without_education_account_can_still_pay_online |
| TC-039 | Student with a Closed EA can pay online only | test_f93_method_and_eligibility.py::test_tc_039_closed_education_account_cannot_be_used_for_payment |
| TC-040 | Active EA with zero balance offers online payment only | test_f93_method_and_eligibility.py::test_tc_040_zero_balance_offers_online_payment_only<br>test_f93_method_and_eligibility.py::test_tc_040_zero_balance_offers_online_payment_only_simulated_wallet |
| TC-041 | Balance below the amount to pay disables EA and suggests split | test_f93_method_and_eligibility.py::test_tc_041_tc_046_low_balance_shows_reason_to_pay_the_rest_online<br>test_f93_method_and_eligibility.py::test_tc_041_balance_below_amount_disables_education_account_and_offers_both |
| TC-042 | Balance equal to the amount to pay allows EA and online but not split | test_f93_method_and_eligibility.py::test_tc_042_balance_equal_to_amount_allows_education_account_and_online_but_not_both |
| TC-043 | Balance above the amount to pay allows EA and online but not split | test_f93_method_and_eligibility.py::test_tc_043_balance_above_amount_allows_education_account_and_online_but_not_both |
| TC-045 | The EA is suggested when the balance is enough but nothing is debited until the Parent confirms | test_f93_method_and_eligibility.py::test_tc_045_education_account_is_suggested_but_nothing_is_debited_before_confirm |
| TC-046 | Selecting EA with a low balance is refused with the reason and nothing changes | test_f93_method_and_eligibility.py::test_tc_041_tc_046_low_balance_shows_reason_to_pay_the_rest_online<br>test_f93_method_and_eligibility.py::test_tc_046_education_account_cannot_be_chosen_when_balance_is_low |
| TC-047 | API refuses the EA method when the balance is too low | test_f93_method_and_eligibility.py::test_tc_047_api_refuses_education_account_method_when_balance_is_too_low |
| TC-050 | Default split proposes the whole balance as the EA part and calculates the online part | test_f93_method_and_eligibility.py::test_tc_050_default_both_proposes_whole_balance_as_education_account_part |
| TC-051 | The Parent can lower the EA part and the online part updates | test_f93_method_and_eligibility.py::test_tc_051_parent_can_lower_the_education_account_part |
| TC-052 | The online part cannot be typed by the Parent | test_f93_method_and_eligibility.py::test_tc_052_online_part_cannot_be_typed |
| TC-063 | Review screen for an EA payment shows the amounts and the balance after payment | test_f93_method_and_eligibility.py::test_tc_063_review_screen_shows_balance_after_payment<br>test_f93_method_and_eligibility.py::test_tc_063_review_screen_of_education_account_payment_debits_nothing |
| TC-065 | Paying a 50.00 invoice with the EA debits the balance once and marks the invoice Paid | test_f94_pay_with_ea.py::test_tc_065_tc_070_tc_129_pay_one_charge_with_education_account_end_to_end |
| TC-067 | Paying a two line invoice of 130.00 debits the full Net amount | test_f94_pay_with_ea.py::test_tc_067_two_charges_in_one_payment_create_one_invoice_with_two_lines |
| TC-070 | After an EA payment the list shows the new balance and no longer shows the invoice | test_f94_pay_with_ea.py::test_tc_065_tc_070_tc_129_pay_one_charge_with_education_account_end_to_end |
| TC-077 | Double click on Confirm creates one transaction and debits once | test_f94_pay_with_ea.py::test_tc_077_double_click_on_authorize_sends_one_checkout_request |
| TC-078 | The same request sent again with the same key returns the first result | test_f94_pay_with_ea.py::test_tc_078_tc_080_same_idempotency_key_returns_first_result_and_pays_once |
| TC-080 | A key of 100 characters is accepted | test_f94_pay_with_ea.py::test_tc_078_tc_080_same_idempotency_key_returns_first_result_and_pays_once |
| TC-081 | A key that is missing, empty or 101 characters long is refused | test_f93_method_and_eligibility.py::test_tc_081_api_refuses_missing_empty_or_too_long_idempotency_key<br>test_f93_method_and_eligibility.py::test_tc_081_refused_key_on_a_real_charge_creates_nothing_and_keeps_balance |
| TC-084 | Confirming an invoice that was paid meanwhile is refused | test_f94_pay_with_ea.py::test_tc_084_charge_already_paid_in_another_tab_is_refused_without_double_charge<br>test_f94_pay_with_ea.py::test_tc_084_tc_086_stale_checkout_clears_selection_and_reloads_the_list |
| TC-086 | Confirming an invoice that was cancelled meanwhile is refused | test_f94_pay_with_ea.py::test_tc_084_tc_086_stale_checkout_clears_selection_and_reloads_the_list |
| TC-087 | Review screen for an online payment has no EA part | test_f95_online_and_split.py::test_tc_087_tc_088_tc_089_pay_one_charge_online_leaves_education_account_untouched |
| TC-088 | A student without an EA pays online and the invoice becomes Paid | test_f95_online_and_split.py::test_tc_087_tc_088_tc_089_pay_one_charge_online_leaves_education_account_untouched |
| TC-089 | A student with an EA who pays online keeps the EA balance | test_f95_online_and_split.py::test_tc_087_tc_088_tc_089_pay_one_charge_online_leaves_education_account_untouched |
| TC-090 | Provider failure returns the invoice to Issued and nothing is charged | test_f95_online_and_split.py::test_tc_090_tc_139_charge_is_available_again_after_online_failure |
| TC-097 | Split of EA 20.00 and online 30.00 pays a 50.00 invoice | test_f95_online_and_split.py::test_tc_097_tc_130_split_payment_succeeds_with_both_funding_sources |
| TC-100 | Review screen for a split shows both parts and the balance after payment | test_f93_method_and_eligibility.py::test_tc_100_review_of_split_payment_shows_both_parts |
| TC-101 | While the online part is pending the waiting screen says the EA part is already taken | test_f97_result_and_receipt.py::test_tc_101_pending_split_says_education_account_part_is_already_taken |
| TC-103 | Online failure after the EA debit returns the EA part | test_f95_online_and_split.py::test_tc_103_tc_137_failed_online_part_returns_the_education_account_part |
| TC-125 | The waiting screen shows the pending notice, a temporary reference and the actions | test_f97_result_and_receipt.py::test_tc_125_pending_screen_says_processing_and_offers_no_failure_or_retry |
| TC-126 | Refreshing the waiting screen shows the success screen after the result arrives | test_f97_result_and_receipt.py::test_tc_126_waiting_screen_turns_into_success_without_reload |
| TC-128 | The verifying state does not say the payment failed and offers no retry | test_f97_result_and_receipt.py::test_tc_128_verifying_state_does_not_say_the_payment_failed_and_offers_no_retry<br>test_f97_result_and_receipt.py::test_tc_128_verifying_state_names_the_education_account_part_that_was_taken |
| TC-129 | The success screen of an EA payment shows reference, time, part and total | test_f94_pay_with_ea.py::test_tc_065_tc_070_tc_129_pay_one_charge_with_education_account_end_to_end<br>test_f97_result_and_receipt.py::test_tc_129_success_screen_of_education_account_payment_shows_reference_time_part_and_total |
| TC-130 | The success screen of a split payment shows both parts | test_f95_online_and_split.py::test_tc_097_tc_130_split_payment_succeeds_with_both_funding_sources<br>test_f97_result_and_receipt.py::test_tc_130_success_screen_of_split_payment_shows_both_parts |
| TC-131 | The receipt PDF of an EA payment can be downloaded | test_f97_result_and_receipt.py::test_tc_131_tc_132_receipt_pdf_can_be_downloaded |
| TC-132 | The receipt PDF of a split payment shows two parts | test_f97_result_and_receipt.py::test_tc_131_tc_132_receipt_pdf_can_be_downloaded |
| TC-133 | The receipt can be printed | test_f97_result_and_receipt.py::test_tc_133_print_receipt_opens_the_print_dialog |
| TC-135 | The paid at time is shown in Singapore time | test_f97_result_and_receipt.py::test_tc_135_completed_time_is_shown_in_singapore_time |
| TC-136 | The failure screen of an online payment shows the message, the reason and the actions | test_f95_online_and_split.py::test_tc_136_online_payment_failure_shows_failed_result_and_keeps_balance<br>test_f97_result_and_receipt.py::test_tc_136_failure_screen_shows_message_and_actions_without_receipt<br>test_f97_result_and_receipt.py::test_tc_136_failure_screen_shows_the_reason |
| TC-137 | The failure screen of a split payment says the EA part was returned | test_f95_online_and_split.py::test_tc_103_tc_137_failed_online_part_returns_the_education_account_part<br>test_f97_result_and_receipt.py::test_tc_137_failed_split_with_returned_education_account_part_says_the_amount_was_returned |
| TC-138 | The failure message hides technical details | test_f97_result_and_receipt.py::test_tc_138_server_error_on_result_hides_technical_details |
| TC-139 | Exit on the failure screen returns to the invoice list with the invoice still Issued | test_f95_online_and_split.py::test_tc_090_tc_139_charge_is_available_again_after_online_failure |
| TC-140 | Try again after a failure creates a new transaction with a new key and can succeed | test_f97_result_and_receipt.py::test_tc_140_failure_screen_offers_try_again |
| TC-141 | No retry is possible while the EA part has not been returned | test_f97_result_and_receipt.py::test_tc_141_reconciliation_with_education_account_still_taken_warns_and_offers_no_retry |
| TC-142 | A session that ends before the confirm creates no transaction | test_f91_access_and_child_list.py::test_tc_142_session_ended_before_confirm_creates_no_transaction |
| TC-144 | A system error on confirm shows a safe message and changes no data | test_f97_result_and_receipt.py::test_tc_144_server_error_on_confirm_shows_safe_message_and_creates_nothing |
| TC-164 | System error while loading the invoice list shows a safe message | test_f92_outstanding_and_balance.py::test_tc_164_system_error_on_charge_list_shows_safe_message_and_retry |

## Case chưa tự động hóa

| Case | Tiêu đề | Lý do |
|---|---|---|
| TC-002 | Failed Singpass sign in creates no session | Cần phụ huynh thứ hai hoặc kịch bản đăng nhập thất bại hoặc bị hủy trên MockPass. Dữ liệu mẫu hiện chỉ map một persona (S7890123F). |
| TC-003 | Cancelled Singpass sign in creates no session | Cần phụ huynh thứ hai hoặc kịch bản đăng nhập thất bại hoặc bị hủy trên MockPass. Dữ liệu mẫu hiện chỉ map một persona (S7890123F). |
| TC-009 | Second guardian linked to the same child sees the same child and invoices | Cần phụ huynh thứ hai hoặc kịch bản đăng nhập thất bại hoặc bị hủy trên MockPass. Dữ liệu mẫu hiện chỉ map một persona (S7890123F). |
| TC-016 | A guardian cannot open a child who is linked only to another Parent | Cần phụ huynh thứ hai hoặc kịch bản đăng nhập thất bại hoặc bị hủy trên MockPass. Dữ liệu mẫu hiện chỉ map một persona (S7890123F). |
| TC-019 | An invoice opens to its lines grouped by fee type with fee components and GST | Mô hình hóa đơn của R9 không có trong UI thật: UI liệt kê khoản phí (charge), không có hóa đơn, dòng theo loại phí, GST hay trạng thái hóa đơn trước khi thanh toán (ASM-R9-UI-01). |
| TC-022 | Invoice due date is the earliest due date of its lines | Mô hình hóa đơn của R9 không có trong UI thật: UI liệt kê khoản phí (charge), không có hóa đơn, dòng theo loại phí, GST hay trạng thái hóa đơn trước khi thanh toán (ASM-R9-UI-01). |
| TC-024 | Paid, Cancelled and Draft invoices are not in the list | Mô hình hóa đơn của R9 không có trong UI thật: UI liệt kê khoản phí (charge), không có hóa đơn, dòng theo loại phí, GST hay trạng thái hóa đơn trước khi thanh toán (ASM-R9-UI-01). |
| TC-025 | An invoice waiting for payment is shown as Pending and cannot be selected | Mô hình hóa đơn của R9 không có trong UI thật: UI liệt kê khoản phí (charge), không có hóa đơn, dòng theo loại phí, GST hay trạng thái hóa đơn trước khi thanh toán (ASM-R9-UI-01). |
| TC-027 | Demo data is labelled as sample data | UI thật không có nhãn dữ liệu mẫu. Cần BA xác nhận bản build thật có cần nhãn này không. |
| TC-034 | A child whose only open invoice is waiting for payment is not shown the empty state | Mô hình hóa đơn của R9 không có trong UI thật: UI liệt kê khoản phí (charge), không có hóa đơn, dòng theo loại phí, GST hay trạng thái hóa đơn trước khi thanh toán (ASM-R9-UI-01). |
| TC-048 | API refuses EA and split for a student without an EA | Cần học sinh không có Education Account hoặc có EA Closed trong dữ liệu thật để thấy API từ chối. Giả lập bằng page.route chỉ đổi phản hồi trong trình duyệt, không đổi máy chủ. Phần giao diện đã có ở TC-038 và TC-039. |
| TC-049 | API refuses EA and split when the EA is Closed | Cần học sinh không có Education Account hoặc có EA Closed trong dữ liệu thật để thấy API từ chối. Giả lập bằng page.route chỉ đổi phản hồi trong trình duyệt, không đổi máy chủ. Phần giao diện đã có ở TC-038 và TC-039. |
| TC-053 | An EA part of zero is refused and the Parent stays on the screen | UI không có ô nhập phần Education Account (phần chia do hệ thống tự tính, ASM-R9-UI-03) và API checkout không nhận số tiền từng phần, nên không có gì để thử. |
| TC-054 | API refuses a split with an online part of zero | UI không có ô nhập phần Education Account (phần chia do hệ thống tự tính, ASM-R9-UI-03) và API checkout không nhận số tiền từng phần, nên không có gì để thử. |
| TC-055 | API refuses a split whose parts add up to less than the amount to pay | UI không có ô nhập phần Education Account (phần chia do hệ thống tự tính, ASM-R9-UI-03) và API checkout không nhận số tiền từng phần, nên không có gì để thử. |
| TC-056 | API refuses a split whose parts add up to more than the amount to pay | UI không có ô nhập phần Education Account (phần chia do hệ thống tự tính, ASM-R9-UI-03) và API checkout không nhận số tiền từng phần, nên không có gì để thử. |
| TC-057 | API refuses an EA part above the available balance | UI không có ô nhập phần Education Account (phần chia do hệ thống tự tính, ASM-R9-UI-03) và API checkout không nhận số tiền từng phần, nên không có gì để thử. |
| TC-058 | API refuses a negative EA part | UI không có ô nhập phần Education Account (phần chia do hệ thống tự tính, ASM-R9-UI-03) và API checkout không nhận số tiền từng phần, nên không có gì để thử. |
| TC-062 | A very small EA part is accepted because the EA part has no minimum | UI không có ô nhập phần Education Account (phần chia do hệ thống tự tính, ASM-R9-UI-03) và API checkout không nhận số tiền từng phần, nên không có gì để thử. |
| TC-066 | Status changes of an EA payment follow Appendix A and are written to the audit log | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-068 | Balance equal to the amount to pay is paid and the balance becomes 0.00 | Cần ví có số dư đúng bằng số tiền cần trả rồi trả thật. Dữ liệu mẫu không có. Phần hiển thị đã có ở TC-042. |
| TC-071 | Balance falling below the amount before confirm fails the EA leg and changes nothing | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-072 | Function 1 error during the debit fails the payment and the invoice is not Paid | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-073 | Unclear debit result with Function 1 confirming nothing was debited fails the leg | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-074 | Unclear debit result with Function 1 confirming the debit leads to a reversal | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-075 | Unclear debit result that stays unclear moves to ReconciliationRequired | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-076 | Function 1 treats the same FundingReference as one debit | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-079 | The same key can be used by two different Parents | Cần hai phụ huynh khác nhau gửi cùng một khóa. Dữ liệu mẫu chỉ có một persona. |
| TC-082 | Two requests at the same time for one invoice give one payment and one refusal | Cần hai yêu cầu gửi song song cho một khoản phí. API đồng bộ của Playwright không đảm bảo song song, nên dùng k6 hoặc JMeter. |
| TC-083 | Two guardians confirming the same invoice at the same time give one payment | Cần phụ huynh thứ hai hoặc kịch bản đăng nhập thất bại hoặc bị hủy trên MockPass. Dữ liệu mẫu hiện chỉ map một persona (S7890123F). |
| TC-085 | Confirming an invoice that is waiting for another payment is refused | Cần giữ một giao dịch ở trạng thái Pending (đang ở trang cổng) rồi thử trả lại khoản đó từ tab khác. Chưa làm. |
| TC-091 | Cancel on the provider page returns the invoice to Issued | Simulator thanh toán không có nút Hủy (chỉ Pay successful và Pay failed), nên không thử được hủy ở trang nhà cung cấp. |
| TC-092 | An expired provider payment session fails the online leg | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-094 | Closing the browser on the provider page keeps the payment Pending until the result arrives | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-095 | A provider timeout keeps the leg Pending and does not mark it Failed | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-096 | No card data is stored after an online payment | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-098 | The EA is debited before the online payment session is created | Thứ tự gọi (trừ EA trước khi tạo phiên online) chỉ kiểm được bằng nhật ký dịch vụ hoặc cơ sở dữ liệu. |
| TC-099 | Split with a lowered EA part of 10.00 and an online part of 40.00 pays the invoice | Hạ phần Education Account xuống 10.00: UI không cho chỉnh (ASM-R9-UI-03). Xem TC-051. |
| TC-102 | EA debit fails before the online part: no payment session and no online charge | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-104 | Cancel at the provider after the EA debit returns the EA part | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-105 | An expired provider session after the EA debit returns the EA part | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-107 | A failed reversal moves the payment to ReconciliationRequired | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-108 | A failure after the EA debit and before the online session is cleaned up by the sweep | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-109 | The sweep leaves a split payment alone when the online leg exists | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-110 | A late provider success after the EA was returned is not paid and goes to manual handling | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-111 | A valid callback is recorded at once and processed later | Thuộc F9.6: cần gọi webhook có chữ ký của nhà cung cấp, đọc bảng webhook hoặc chạy job đối soát. Ngoài phạm vi kiểm thử qua giao diện. |
| TC-112 | A callback with a wrong signature is rejected and changes nothing | Thuộc F9.6: cần gọi webhook có chữ ký của nhà cung cấp, đọc bảng webhook hoặc chạy job đối soát. Ngoài phạm vi kiểm thử qua giao diện. |
| TC-113 | A callback without a signature is rejected | Thuộc F9.6: cần gọi webhook có chữ ký của nhà cung cấp, đọc bảng webhook hoặc chạy job đối soát. Ngoài phạm vi kiểm thử qua giao diện. |
| TC-114 | A callback whose content was changed after signing is rejected | Thuộc F9.6: cần gọi webhook có chữ ký của nhà cung cấp, đọc bảng webhook hoặc chạy job đối soát. Ngoài phạm vi kiểm thử qua giao diện. |
| TC-115 | The same event sent twice is applied once | Thuộc F9.6: cần gọi webhook có chữ ký của nhà cung cấp, đọc bảng webhook hoặc chạy job đối soát. Ngoài phạm vi kiểm thử qua giao diện. |
| TC-119 | Only a hash of the callback is stored | Thuộc F9.6: cần gọi webhook có chữ ký của nhà cung cấp, đọc bảng webhook hoặc chạy job đối soát. Ngoài phạm vi kiểm thử qua giao diện. |
| TC-120 | A lost webhook is replaced by the provider status query: success | Thuộc F9.6: cần gọi webhook có chữ ký của nhà cung cấp, đọc bảng webhook hoặc chạy job đối soát. Ngoài phạm vi kiểm thử qua giao diện. |
| TC-121 | A lost webhook is replaced by the provider status query: failure | Thuộc F9.6: cần gọi webhook có chữ ký của nhà cung cấp, đọc bảng webhook hoặc chạy job đối soát. Ngoài phạm vi kiểm thử qua giao diện. |
| TC-122 | A Pending leg that stays unclear beyond the threshold moves to ReconciliationRequired | Thuộc F9.6: cần gọi webhook có chữ ký của nhà cung cấp, đọc bảng webhook hoặc chạy job đối soát. Ngoài phạm vi kiểm thử qua giao diện. |
| TC-123 | A webhook and a status query that arrive together are applied once | Thuộc F9.6: cần gọi webhook có chữ ký của nhà cung cấp, đọc bảng webhook hoặc chạy job đối soát. Ngoài phạm vi kiểm thử qua giao diện. |
| TC-127 | A Parent who comes back to a pending invoice cannot start a second payment | Cần danh sách khoản phí khi có giao dịch Pending mở. UI thật cho khoản biến mất khỏi danh sách khi tạo thanh toán, không có trạng thái Pending trên từng khoản. |
| TC-143 | A session that ends after the confirm does not stop the payment | Cần tiêm lỗi vào Function 1, cổng thanh toán hoặc hạ tầng (ngắt kết nối, hết hạn phiên, timeout, hoàn tiền lỗi). Simulator chỉ có hai nút Pay successful và Pay failed. |
| TC-145 | The seed data follows every invoice rule of BR-F9-12 | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-146 | An Issued invoice with Net 0.00 is refused and a Draft with Net 0.00 is accepted | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-147 | A line with Subsidy equal to Gross is refused and Subsidy just below Gross is accepted | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-148 | A student charge cannot be placed on two invoices | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-149 | A line from another school than the invoice is refused | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-150 | Negative amounts are refused | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-151 | Date fields follow the invoice status | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-152 | The currency defaults to SGD | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-153 | A second open transaction for an invoice is refused by the database | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-154 | A second Succeeded transaction for an invoice is refused | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-155 | An idempotency key is unique for a Parent and can repeat across Parents | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-156 | A FundingReference is unique and a split uses two different references | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-157 | Wallet and provider fields depend on the leg method | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-158 | Ledger and provider IDs are stored when they must be and are unique | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-159 | Leg amounts add up to the transaction and the transaction equals the invoice Net | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-160 | An amount other than the invoice Net cannot be requested | API checkout không nhận số tiền do client gửi (chỉ studentId, chargeIds, method, walletId, returnUrl). Số tiền tính ở máy chủ từ chargeIds, nên không có tham số để thử. |
| TC-161 | Settled above Requested and a leg amount of zero are refused | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-162 | CompletedAt is empty while processing and filled when the transaction is final | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. |
| TC-166 | A second guardian pays an invoice of the shared child and the payment is recorded for that guardian | Cần guardian thứ hai (PAR-D) của cùng con để thanh toán rồi đăng nhập lại bằng PAR-A. Dữ liệu mẫu hiện chỉ map một persona. |
| TC-167 | Status changes of a split payment that is returned are written to the audit log | Cần đọc nhật ký audit của transaction, hai leg và invoice theo thứ tự thời gian. Chỉ đọc được bằng SQL, không có trên UI. |
| TC-168 | Two invoices cannot share an invoice number | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. Riêng TC-169, phần quan sát được qua UI (hai dòng của một hóa đơn có số dòng 1 và 2) nằm trong test của TC-067. |
| TC-169 | The line number of an invoice line is above 0 and unique inside its invoice | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. Riêng TC-169, phần quan sát được qua UI (hai dòng của một hóa đơn có số dòng 1 và 2) nằm trong test của TC-067. |
| TC-171 | The sequence number of a funding leg is above 0 and unique inside its transaction | Kiểm ràng buộc cơ sở dữ liệu (CHECK, UNIQUE, khóa ngoại, nhật ký). Cần truy cập SQL Server của QA, viết thành kịch bản SQL riêng, không thuộc bộ UI. Riêng TC-169, phần quan sát được qua UI (hai dòng của một hóa đơn có số dòng 1 và 2) nằm trong test của TC-067. |

## Case tự động hóa mà bản rev FS09 đã đổi

Bản rev đổi Preconditions, Test Data hoặc Expected Result của 75 case cũ, trong đó 32 case có test. Cột cuối ghi việc đã làm ở test. Các hậu điều kiện về nhật ký, bảng ledger và số dư trên hệ thống ngoài e-service không có trên UI nên chưa kiểm.

| Case | Phần đã đổi | Việc đã làm ở test |
|---|---|---|
| TC-015 | Test Data, Expected Result | Không đổi test. API dùng mã lạ nên không có giao dịch TXN-B1 của gia đình khác; phần 'TXN-B1 vẫn Succeeded' cần phụ huynh thứ hai. |
| TC-035 | Expected Result | Thêm assert_nothing_created: không có POST /checkout, danh sách khoản và số dư EA giữ nguyên. |
| TC-036 | Expected Result | Thêm assert_nothing_created: không có POST /checkout, danh sách khoản và số dư EA giữ nguyên. |
| TC-038 | Expected Result | Thêm kiểm tra không có POST /checkout. Trang bị lỗi ví chặn nên không đọc lại danh sách. |
| TC-039 | Expected Result | Thêm assert_nothing_created: không có POST /checkout, danh sách khoản và số dư EA giữ nguyên. (ví giả lập, nên chỉ so danh sách khoản) |
| TC-040 | Expected Result | Thêm assert_nothing_created: không có POST /checkout, danh sách khoản và số dư EA giữ nguyên. Thêm bản ví giả lập 0.00 vì dữ liệu thật không có con ví 0 còn khoản phí. |
| TC-041 | Expected Result | Thêm assert_nothing_created: không có POST /checkout, danh sách khoản và số dư EA giữ nguyên. |
| TC-042 | Expected Result | Thêm assert_nothing_created: không có POST /checkout, danh sách khoản và số dư EA giữ nguyên. (ví giả lập, nên chỉ so danh sách khoản) |
| TC-043 | Expected Result | Thêm assert_nothing_created: không có POST /checkout, danh sách khoản và số dư EA giữ nguyên. |
| TC-050 | Expected Result | Thêm assert_nothing_created: không có POST /checkout, danh sách khoản và số dư EA giữ nguyên. |
| TC-063 | Expected Result | Thêm test màn xem lại EA chưa trừ gì (assert_nothing_created). Test known_defect về số dư sau thanh toán giữ nguyên. |
| TC-067 | Expected Result | Test mutating đọc thêm transaction, leg và invoice qua API (assert_backend_state). Thêm dòng nguồn tiền EA Succeeded, Invoice status Paid và số dòng 1, 2. |
| TC-070 | Expected Result | Test mutating đọc thêm transaction, leg và invoice qua API (assert_backend_state). |
| TC-077 | Expected Result | Test mutating đọc thêm transaction, leg và invoice qua API (assert_backend_state). Thêm tiêu đề Payment successful và Invoice status Paid. |
| TC-078 | Preconditions, Expected Result | Test mutating đọc thêm transaction, leg và invoice qua API (assert_backend_state). |
| TC-080 | Preconditions, Expected Result | Test mutating đọc thêm transaction, leg và invoice qua API (assert_backend_state). |
| TC-081 | Preconditions, Expected Result | Thêm test mutating trên khoản thật: khóa sai bị từ chối, khoản còn nợ, số dư EA không đổi. Test dùng mã lạ giữ nguyên. |
| TC-084 | Test Data, Expected Result | Thêm kiểm tra tab sau không lưu mã giao dịch thứ hai, khoản đã trả không quay lại danh sách, số dư không đổi. |
| TC-087 | Expected Result | Thêm kiểm tra màn xem lại chưa gửi POST /checkout. Test mutating đọc thêm transaction, leg và invoice qua API (assert_backend_state). |
| TC-089 | Expected Result | Test mutating đọc thêm transaction, leg và invoice qua API (assert_backend_state). Chỉ có leg online, không có leg EA. |
| TC-100 | Expected Result | Thêm assert_nothing_created: không có POST /checkout, danh sách khoản và số dư EA giữ nguyên. |
| TC-101 | Preconditions, Expected Result | Thêm kiểm tra hai dòng nguồn tiền: EA Succeeded và online Pending. Câu 'EA đã bị trừ' vẫn là known_defect. |
| TC-103 | Preconditions | Test mutating đọc thêm transaction, leg và invoice qua API (assert_backend_state). Mong đợi transaction Failed, leg EA Reversed, leg online Failed, invoice Issued. |
| TC-125 | Expected Result | Test đổi tên chỉ còn TC-125 (TC-128 tách riêng). Thêm kiểm tra dòng nguồn tiền online Pending. |
| TC-126 | Expected Result | Mock chuyển sang leg online Succeeded. Thêm kiểm tra dòng nguồn tiền và Invoice status Paid. |
| TC-128 | Preconditions, Expected Result | Thêm hai test: trạng thái ReconciliationRequired không nói thất bại và không có Try again; câu 'EA đã bị trừ' là known_defect. |
| TC-129 | Expected Result | Giữ test mocked. Thêm ghi chú: số dư EA 150.00 không hiện trên màn kết quả, kiểm ở TC-065. |
| TC-130 | Expected Result | Thêm Invoice status Paid ở test mocked. Test mutating đọc thêm transaction, leg và invoice qua API (assert_backend_state). |
| TC-136 | Expected Result | Test mutating đọc thêm transaction, leg và invoice qua API (assert_backend_state). Việc invoice trở lại Issued kiểm ở test TC-090 và TC-139. |
| TC-137 | Expected Result | Thêm test transaction Failed với leg EA Reversed (known_defect: UI chỉ có câu 'đã hoàn' khi ReconciliationRequired). Test cũ thành extra. |
| TC-141 | Test Data, Expected Result | Thêm kiểm tra leg EA giữ Succeeded, leg online Failed và không có POST /checkout mới. |
| TC-142 | Expected Result | Không đổi test. Phiên đã hết hạn nên không đọc được invoice và số dư; test chỉ kiểm không có POST /checkout. |

Các case chưa có test và đã đổi ở bản rev: TC-009, TC-025, TC-034, TC-048, TC-049, TC-053, TC-054, TC-055, TC-056, TC-057, TC-058, TC-062, TC-066, TC-068, TC-079, TC-082, TC-083, TC-085, TC-094, TC-098, TC-099, TC-104, TC-105, TC-107, TC-108, TC-109, TC-110, TC-111, TC-112, TC-113, TC-114, TC-115, TC-119, TC-120, TC-121, TC-122, TC-123, TC-127, TC-143, TC-153, TC-154, TC-160, TC-162.

