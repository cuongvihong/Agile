"""Trang /billing: chọn tài khoản giáo dục (con) để xem phí. Tương ứng SCR-01 Choose child của R9."""
from __future__ import annotations

import re

from playwright.sync_api import Locator, expect

from data import ui_text as T
from pages.base_page import BasePage, norm


class AccountsPage(BasePage):
    PATH = "/billing"

    @property
    def heading(self) -> Locator:
        return self.page.get_by_role("heading", name=T.H_ACCOUNTS, level=1)

    @property
    def account_list(self) -> Locator:
        return self.page.get_by_role("list", name=T.LIST_ACCOUNTS)

    @property
    def cards(self) -> Locator:
        return self.account_list.get_by_role("listitem")

    @property
    def error_heading(self) -> Locator:
        return self.page.get_by_role("heading", name=T.ACCOUNTS_ERROR)

    @property
    def empty_title(self) -> Locator:
        return self.page.get_by_text(T.ACCOUNTS_EMPTY, exact=True)

    @property
    def retry_button(self) -> Locator:
        return self.page.get_by_role("button", name=T.RETRY)

    def open(self) -> "AccountsPage":
        self.page.goto(self.url(self.PATH))
        self.wait_loaded()
        return self

    def wait_loaded(self, timeout: int = 20_000) -> None:
        """Chờ một trong ba trạng thái: có danh sách, lỗi tải, hoặc rỗng."""
        expect(self.heading.or_(self.error_heading).or_(self.empty_title).first).to_be_visible(timeout=timeout)

    def read_cards(self) -> list[dict]:
        """Mỗi thẻ: name, code, status, student_id (từ liên kết), text (toàn bộ chữ của thẻ)."""
        out: list[dict] = []
        for card in self.cards.all():
            text = norm(card.inner_text())
            href = card.get_by_role("link").first.get_attribute("href") or ""
            code = re.search(r"Account\s+(\S+)", text)
            status = re.search(r"Status:\s*(.+?)(?:\s+View fees|$)", text)
            out.append({"name": norm(card.get_by_role("heading").first.inner_text()),
                        "code": code.group(1) if code else "",
                        "status": status.group(1).strip() if status else "",
                        "student_id": href.rstrip("/").rsplit("/", 1)[-1],
                        "text": text})
        return out

    def read_all(self) -> list[dict]:
        """Đọc mọi con, qua các trang nếu có phân trang (6 con mỗi trang)."""
        out: list[dict] = []
        for _ in range(20):
            out.extend(self.read_cards())
            nxt = self.page.get_by_role("button", name=re.compile(r"^next", re.I))
            if nxt.count() == 0 or nxt.first.is_disabled():
                break
            nxt.first.click()
            self.page.wait_for_load_state("networkidle")
        return out

    def open_child(self, name: str) -> None:
        self.page.get_by_role("link", name=f"View fees for {name}").click()
        self.page.wait_for_url(re.compile(r"/billing/[^/]+$"))
